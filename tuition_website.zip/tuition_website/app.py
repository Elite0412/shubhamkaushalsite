import os
import psycopg2
from psycopg2.extras import RealDictCursor
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file
from werkzeug.utils import secure_filename
from datetime import datetime
import io

app = Flask(__name__)
app.secret_key = 'shubham_kaushal_secret_key_2024'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Database connection
DATABASE_URL = "postgresql://neondb_owner:npg_kLfzDPTxv30t@ep-still-band-a47x5t39-pooler.us-east-1.aws.neon.tech/neondb?sslmode=require"

def get_db_connection():
    conn = psycopg2.connect(DATABASE_URL)
    return conn

def init_db():
    """Initialize database tables"""
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Create notes table
    cur.execute('''
        CREATE TABLE IF NOT EXISTS notes (
            id SERIAL PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            filename VARCHAR(255) NOT NULL,
            file_data BYTEA NOT NULL,
            file_type VARCHAR(50) NOT NULL,
            upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    cur.close()
    conn.close()

# Initialize database on startup
try:
    init_db()
except Exception as e:
    print(f"Database initialization error: {e}")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/notes')
def notes():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT id, title, description, filename, file_type, upload_date FROM notes ORDER BY upload_date DESC')
    notes_list = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('notes.html', notes=notes_list)

@app.route('/download/<int:note_id>')
def download_note(note_id):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT filename, file_data, file_type FROM notes WHERE id = %s', (note_id,))
    note = cur.fetchone()
    cur.close()
    conn.close()
    
    if note:
        return send_file(
            io.BytesIO(note['file_data']),
            mimetype=note['file_type'],
            as_attachment=True,
            download_name=note['filename']
        )
    return "File not found", 404

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        password = request.form.get('password')
        if password == 'ShubhamKaushal01010101':
            session['admin_logged_in'] = True
            return redirect(url_for('admin_panel'))
        else:
            flash('Incorrect password!', 'error')
    return render_template('admin_login.html')

@app.route('/admin/panel')
def admin_panel():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('SELECT * FROM notes ORDER BY upload_date DESC')
    notes_list = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('admin_panel.html', notes=notes_list)

@app.route('/admin/upload', methods=['POST'])
def admin_upload():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    
    title = request.form.get('title')
    description = request.form.get('description')
    file = request.files.get('file')
    
    if not title or not file:
        flash('Title and file are required!', 'error')
        return redirect(url_for('admin_panel'))
    
    filename = secure_filename(file.filename)
    file_data = file.read()
    file_type = file.content_type
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO notes (title, description, filename, file_data, file_type) VALUES (%s, %s, %s, %s, %s)',
        (title, description, filename, file_data, file_type)
    )
    conn.commit()
    cur.close()
    conn.close()
    
    flash('Note uploaded successfully!', 'success')
    return redirect(url_for('admin_panel'))

@app.route('/admin/delete/<int:note_id>', methods=['POST'])
def admin_delete(note_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM notes WHERE id = %s', (note_id,))
    conn.commit()
    cur.close()
    conn.close()
    
    flash('Note deleted successfully!', 'success')
    return redirect(url_for('admin_panel'))

@app.route('/admin/edit/<int:note_id>', methods=['GET', 'POST'])
def admin_edit(note_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        cur.execute(
            'UPDATE notes SET title = %s, description = %s WHERE id = %s',
            (title, description, note_id)
        )
        conn.commit()
        cur.close()
        conn.close()
        
        flash('Note updated successfully!', 'success')
        return redirect(url_for('admin_panel'))
    
    cur.execute('SELECT * FROM notes WHERE id = %s', (note_id,))
    note = cur.fetchone()
    cur.close()
    conn.close()
    
    return render_template('admin_edit.html', note=note)

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
