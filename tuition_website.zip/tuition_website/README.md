# Shubham Kaushal Tuition Website

A modern, professional tuition website built with Flask, featuring a light sky blue and cyan theme.

## Features

- **Home Page**: Welcoming hero section with key features
- **Notes Section**: Public access to study materials
- **Contact Page**: Contact information and inquiry form
- **Admin Panel**: Secure area for managing notes (Password: ShubhamKaushal01010101)
  - Upload PDF files, images, and documents
  - Edit note titles and descriptions
  - Delete notes
  - All files stored in Neon PostgreSQL database

## Technology Stack

- **Backend**: Python Flask
- **Database**: Neon PostgreSQL
- **Frontend**: Pure HTML, CSS, JavaScript (No frameworks)
- **Hosting**: Vercel-ready

## Local Development

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
python app.py
```

3. Open browser at `http://localhost:5000`

## Deployment to Vercel

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Login to Vercel:
```bash
vercel login
```

3. Deploy:
```bash
vercel
```

4. For production deployment:
```bash
vercel --prod
```

## Admin Access

- URL: `/admin`
- Password: `ShubhamKaushal01010101`

## Database

The application uses Neon PostgreSQL to store:
- Note titles and descriptions
- Uploaded files (PDFs, images, documents)
- Upload timestamps

Database connection is already configured in `app.py`.

## File Structure

```
tuition_website/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── vercel.json           # Vercel configuration
├── templates/            # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── contact.html
│   ├── notes.html
│   ├── admin_login.html
│   ├── admin_panel.html
│   └── admin_edit.html
└── static/               # Static assets
    ├── css/
    │   └── style.css
    └── js/
        └── script.js
```

## Color Scheme

- Primary: Cyan (#00CED1)
- Secondary: Light Sky Blue (#87CEEB)
- Accent: Turquoise (#40E0D0)
- Background: Alice Blue (#F0F8FF)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Security Notes

- Admin password should be changed in production
- Consider adding environment variables for sensitive data
- HTTPS is recommended for production deployment

## License

All rights reserved - Shubham Kaushal Tuition Classes
